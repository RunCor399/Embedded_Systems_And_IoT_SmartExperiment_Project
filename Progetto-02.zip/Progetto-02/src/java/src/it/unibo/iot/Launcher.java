package it.unibo.iot;

public class Launcher {
    private Launcher() {
    }

    public static void main(final String[] args) {
        View.main(args);
    }
}
