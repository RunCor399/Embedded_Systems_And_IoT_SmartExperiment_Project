#ifndef __POTENZIOMETER__
#define __POTENZIOMETER__

class Potenziometer {

public:
    virtual int getValue() = 0;
};

#endif
