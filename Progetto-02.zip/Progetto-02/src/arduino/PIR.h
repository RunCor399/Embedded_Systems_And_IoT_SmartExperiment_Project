#ifndef __PIR__
#define __PIR__

class PIR {

public:
    virtual int detectPerson() = 0;

};

#endif